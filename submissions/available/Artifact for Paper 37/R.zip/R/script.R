library(ggplot2)
library(plyr)
library(dplyr)
library(viridis)
library(ggrepel)
library(RColorBrewer)
library(extrafont)
library(pwr)

#font_import()
loadfonts()


# Plot for questions based on paper categories, 5:4
values <- read.csv("ClustersFromPapers.csv", header=TRUE)
values$Class <- factor(values$Class, levels = c("Other", "Architecture", "Comprehension", "General", "Testing", "Code", "Meta"))

ggplot(values, aes(Class, Questions)) +
  geom_bar(stat="identity", fill="#D3D3D3", width=0.9) +
  coord_flip(y=c(-9,100)) +
  theme_bw(base_size = 16, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x=element_blank(), y="Number of Questions") +
  geom_text(aes(Class, -7, label=paste0(Questions, " (", Categories, ")")), check_overlap = TRUE) +
  geom_text(aes(Class, 25, label=Class), check_overlap = TRUE)



# Plot for questions based on question classification, 7:6
values <- read.csv("ClustersFromQuestions.csv", header=TRUE)
values$Class <- factor(values$Class, levels = c("General", "Architecture", "Meta", "Code"))
levels(values$Class) <- c("General (60)", "Architecture (134)", "Meta (150)", "Code (112)")
values$Subclass <- factor(values$Subclass, levels = c("", "Intent", "MVC", "Behavior", "People", "Information", "Testing", "Change", "Structure"))

ggplot(values, aes(Subclass)) +
  geom_bar(stat="count", aes(fill=Class), width=0.9) +
  coord_flip(y=c(-5,88)) +
#  scale_fill_viridis(option="C", discrete=TRUE) +
  scale_fill_brewer(palette = "Blues") +
  theme_bw(base_size = 16, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x=element_blank(), y="Number of Questions") +
  geom_text(stat = "count", aes(label=..count..), check_overlap = TRUE, size=5) +
  geom_text(aes(Subclass, 25, label=Subclass), check_overlap = TRUE, size=5)



# Plot for rankings, 3:4
values <- read.csv("NormalizedRatings.csv", header=TRUE)
values$Class <- factor(values$Class, levels = c("Architecture", "Meta", "Code"))
levels(values$Class) <- c("A", "M", "C")
counts <- ddply(values, .(Aspect, Class), summarise, lab = length(Class))

ggplot(values, aes(Class, NormRating)) +
  geom_boxplot() +
  facet_grid(. ~ Aspect) +
  theme_bw(base_size = 18, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.text.y= element_blank(),
        axis.ticks.y = element_blank(),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x=element_blank(), y=element_blank()) +
  geom_text(data = counts, aes(y = -0.1, label = lab), size=4.5, check_overlap = TRUE)




# Plot for overall importance 3:4
values <- read.csv("overallImportance.csv", header=TRUE)
values$type <- factor(values$type, levels = c("Architecture", "Meta", "Code"))
values$imp <- factor(values$imp, levels = c("Not important", "Important"))
levels(values$type) <- c("A", "M", "C")
levels(values$imp) <- c("Not imp.", "Important")

values <- ddply(values, "type", transform, pos=cumsum(val)-0.5*val)

ggplot(values, aes(type, val)) +
  geom_bar(stat="identity", aes(fill=imp), width=0.9) +
  theme_bw(base_size = 18, base_family="Latin Modern") +
  scale_fill_brewer(palette = "Paired") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.text.y= element_blank(),
        axis.ticks.y = element_blank(),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x=element_blank(), y=element_blank()) +
  geom_text(aes(y=pos, label = val), size=4.5, check_overlap = TRUE)



# Plot for importance/correctness questions 9:5

values <- read.csv("questionsRatings_new.csv", header=TRUE)
values$type <- factor(values$type, levels = c("Architecture", "Meta", "Code"))
#values$question <- factor(values$question, levels = 
#                            c("A1", "A2", "A3", "A4", "A5", "A6",
#                              "M1", "M2", "M3", "M4", "M5", "M6",
#                              "C1", "C2", "C3", "C4", "C5", "C6"))
values$info <- factor(values$info, levels = c("Importance", "Correctness"))
values$question <- factor(values$question, levels=c("6", "5", "4", "3", "2", "1"))

values.mean <- values %>%
  group_by(type,info) %>%
  mutate(ymean = mean(val))

ggplot(values.mean, aes(question, val)) +
  geom_bar(stat="identity", fill="#D3D3D3", width=0.9) +
  coord_flip() +
  facet_grid(type ~ info) +
#  scale_fill_brewer(palette = "Paired") +
  theme_bw(base_size = 16, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.ticks.y = element_blank(),
        #axis.text.y = element_blank(),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x=element_blank(), y=element_blank()) +
  geom_errorbar(aes(ymax=ymean, ymin=ymean), color="#0068b4", width=2) +
  geom_label(aes(y=ymean, label=round(ymean, digits=2)), fill="#7FB3D9", size=4.5)
#  stat_summary(aes(group=type), fun.y=mean, geom="line", colour="#0068B4")

# test importance vs correctness

test_frame <- read.csv("importanceVScorrectnessTESTdata_new.csv", header=TRUE)

#check for noarmality
shapiro.test(test_frame$Importance)
shapiro.test(test_frame$Correctness)

#cor.test(test_framex,
#         test_framey,
#         method = "pearson",
#         conf.level = 0.95)

cor.test(test_framex,
         test_framey,
         method = "kendall",
         exact=TRUE,
         continuity = FALSE,
         conf.level = 0.95)

#check statistical power
pwr.r.test(n=17, sig.level=0.05, r=0.508364)

# plot the data just tested
ggplot(test_frame, aes(Importance, Correctness)) +
  geom_point(size=4, color="#0068b4", shape=10) +
  coord_cartesian(c(0,1), c(0,1)) +
  theme_bw(base_size = 16, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        #axis.ticks.y = element_blank(),
        axis.text = element_text(size=10),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
#  labs(x="Importance", y="Correctness") +
  geom_abline(intercept=0, slope=1)


# Plot for correctness/assessment 9:5

values <- read.csv("assVsCorr_new.csv", header=TRUE)
values$Assessment <- factor(values$Assessment, c("Initial", "Final"))

ggplot(values, aes(correct, rating)) +
  geom_point(size=4, color="#0068b4", shape=10) +
  facet_grid(. ~ Assessment) +
  coord_cartesian(c(0,1), c(0,1)) +
  theme_bw(base_size = 20, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        #axis.ticks.y = element_blank(),
        axis.text = element_text(size=12),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x="Correctness", y="Self-Assessment") +
  geom_abline(intercept=0, slope=1)


initial_testData <- values[ which(values$Assessment=='Initial'), ]

#check for noarmality
shapiro.test(initial_testData$rating)
shapiro.test(initial_testData$correct)

cor.test(initial_testData$rating,
         initial_testData$correct,
         method = "kendall",
         exact=TRUE,
         continuity = FALSE,
         conf.level = 0.95)

final_testData <- values[ which(values$Assessment=='Final'), ]

#check for noarmality
shapiro.test(final_testData$rating)
shapiro.test(final_testData$correct)

cor.test(final_testData$rating,
         final_testData$correct,
         method = "kendall",
         exact=TRUE,
         continuity = FALSE,
         conf.level = 0.95)






# plot for file knowledge and times

values <- read.csv("fileTimes_PairedForTest.csv", header=TRUE)

ggplot(values, aes(time, correct)) +
  geom_point(size=4, color="#0068b4", shape=10) +
  facet_grid(level ~ .) +
  theme_bw(base_size = 14, base_family="Latin Modern") +
  theme(legend.position="bottom",
        legend.title=element_blank(),
        legend.background=element_blank(),
        panel.background=element_blank(),
        panel.border=element_rect(color="black", fill=NA, size=1),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        #axis.ticks.y = element_blank(),
        axis.text = element_text(size=10),
        strip.background = element_blank(),
        strip.text.y = element_text(margin = margin(l = 2))) +
  labs(x="Passed time in days", y="Correctness") 

overall_testData <- values[ which(values$level=='Overall'), ]

#check for noarmality
shapiro.test(overall_testData$time)
shapiro.test(overall_testData$correct)

cor.test(overall_testData$time,
         overall_testData$correct,
         method = "kendall",
         exact=TRUE,
         continuity = FALSE,
         conf.level = 0.95)

file_testData <- values[ which(values$level=='File'), ]

#check for noarmality
shapiro.test(file_testData$time)
shapiro.test(file_testData$correct)

cor.test(file_testData$time,
         file_testData$correct,
         method = "kendall",
         exact=TRUE,
         continuity = FALSE,
         conf.level = 0.95)

method_testData <- values[ which(values$level=='Method'), ]

#check for noarmality
shapiro.test(method_testData$time)
shapiro.test(method_testData$correct)

cor.test(method_testData$time,
         method_testData$correct,
         method = "kendall",
         exact=TRUE,
         continuity = FALSE,
         conf.level = 0.95)

# test the distributions (they are not correlated to time)

wilcox.test(file_testData$correct,
            method_testData$correct,
            paired = TRUE)
